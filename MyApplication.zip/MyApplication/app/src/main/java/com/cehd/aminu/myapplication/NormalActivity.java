package com.cehd.aminu.myapplication;

/**
 * Created by aminu on 15/04/2018.
 */

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
public class NormalActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_normal);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.about, menu);
        return true;
    }

}
